package com.tracking.tsaapp.controller;

import com.mongodb.MongoClient;
import com.tracking.tsaapp.dao.ActivityDao;
import com.tracking.tsaapp.dao.UserDao;
import com.tracking.tsaapp.model.Activity;
import com.tracking.tsaapp.model.Position;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "AddActivity", value = "/AddActivity")
public class AddActivity extends HttpServlet {
    private static final long serialVersionUID = 1L;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("login") == null) {
            this.getServletContext()
                    .getRequestDispatcher("/WEB-INF/views/login.jsp")
                    .forward(request, response);
        }else {
            this.getServletContext().getRequestDispatcher("/WEB-INF/views/newActivity.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String type = request.getParameter("sport_list");
        Date datedebut = new Date();
        Date datefin=new Date();
        List<Position> positions=new ArrayList<>();
        Activity act =new Activity(type,session.getAttribute("id").toString(),datedebut,datefin,positions);
        MongoClient mongo = (MongoClient) request.getServletContext()
                .getAttribute("MONGO_CLIENT");
        ActivityDao actDao = new ActivityDao(mongo);
        actDao.createActivity(act);

    }
}
