package com.tracking.tsaapp.controller;

import com.mongodb.MongoClient;
import com.tracking.tsaapp.dao.ActivityDao;
import com.tracking.tsaapp.dao.PositionDao;
import com.tracking.tsaapp.model.Activity;
import com.tracking.tsaapp.model.Position;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;



import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "StartActivity", value = "/StartActivity")
public class StartActivity extends HttpServlet {
    private static final long serialVersionUID = 1L;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("login") == null) {
            this.getServletContext().getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
        }else {
            this.getServletContext().getRequestDispatcher("/WEB-INF/views/start.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String id= session.getAttribute("id").toString();
        MongoClient mongo = (MongoClient) request.getServletContext()
                .getAttribute("MONGO_CLIENT");
        ActivityDao actDao = new ActivityDao(mongo);
        PositionDao pdao =new PositionDao(mongo);
        List<Activity >  activities_collection  =actDao.readAllActivities(id);
        List<Position >  positions_collection  = pdao.readAllPositions();

        String datedebut = request.getParameter("datedebut");
        String datefin = request.getParameter("datefin");
        String nbrminutes = request.getParameter("nbrminutes");
        String type = request.getParameter("type");
        String coords = request.getParameter("iteneraire");
        JSONArray array;
        List<Position> positions=new ArrayList<>();
        try {
            array=new JSONArray(coords);
            for(int i=0; i < array.length(); i++) {
                JSONObject object = array.getJSONObject(i);
                Position p = new Position();
                p.setLatitude(object.getDouble("latitude"));
                p.setLongitude(object.getDouble("longitude"));
                positions.add(p);
                positions_collection.add(p);
            }
        }catch (JSONException e1) {
            e1.printStackTrace();
        }
        Date datestart = null;
        try {
            datestart = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")).parse(datedebut.replaceAll("Z$", "+0000"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Date datefinish = null;
        try {
            datefinish = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")).parse(datefin.replaceAll("Z$", "+0000"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Activity a =new Activity(id,type,datestart,datefinish,positions);
        activities_collection.add(a);
        response.sendRedirect("/webapp/Home");


    }
}
