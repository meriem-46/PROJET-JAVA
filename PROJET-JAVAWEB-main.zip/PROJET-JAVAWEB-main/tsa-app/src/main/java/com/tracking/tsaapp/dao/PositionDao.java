package com.tracking.tsaapp.dao;

import com.mongodb.*;

import com.tracking.tsaapp.converter.PositionConverter;
import com.tracking.tsaapp.model.Position;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.List;

public class PositionDao {
    private DBCollection col;

    public PositionDao(MongoClient mongo) {
        this.col = mongo.getDB("tracking").getCollection("positions");
    }

    public Position createPosition(Position u) {
        DBObject doc = PositionConverter.toDBObject(u);
        this.col.insert(doc);
        ObjectId id = (ObjectId) doc.get("_id");
        u.setId(id.toString());
        return u;
    }

    public void updatePosition(Position u) {
        DBObject query = BasicDBObjectBuilder.start()
                .append("_id", new ObjectId(u.getId())).get();
        this.col.update(query, PositionConverter.toDBObject(u));
    }

    public List<Position> readAllPositions() {
        List<Position> data = new ArrayList<>();
        DBCursor cursor = col.find();
        while (cursor.hasNext()) {
            DBObject doc = cursor.next();
            Position u = PositionConverter.toPosition(doc);
            data.add(u);
        }
        return data;
    }

    public void deletePosition(Position u) {
        DBObject query = BasicDBObjectBuilder.start()
                .append("_id", new ObjectId(u.getId())).get();
        this.col.remove(query);
    }

    public Position readPosition(Position u) {
        DBObject query = BasicDBObjectBuilder.start()
                .append("_id", new ObjectId(u.getId())).get();
        DBObject data = this.col.findOne(query);
        return PositionConverter.toPosition(data);
    }
}
