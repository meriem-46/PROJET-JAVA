package com.tracking.tsaapp.controller;
import com.mongodb.MongoClient;
import com.tracking.tsaapp.dao.UserDao;
import com.tracking.tsaapp.model.User;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Login", value = "/Login")
public class Login extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("login") == null) {
            this.getServletContext()
                    .getRequestDispatcher("/WEB-INF/views/login.jsp")
                    .forward(request, response);
        }else {
            this.getServletContext()
                    .getRequestDispatcher("/WEB-INF/views/home.jsp")
                    .forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String login = request.getParameter("login");
        String password = request.getParameter("password");
        MongoClient mongo = (MongoClient) request.getServletContext()
                .getAttribute("MONGO_CLIENT");
        UserDao userDAO = new UserDao(mongo);
        User user = userDAO.readUser(new User(login,password));
        if (user == null) {
            this.getServletContext()
                    .getRequestDispatcher("/WEB-INF/views/login.jsp")
                    .forward(request, response);
        }else{
            HttpSession session = request.getSession();
            session.setAttribute("login", user.getUsername());
            session.setAttribute("id", user.getId());
            session.setMaxInactiveInterval(60*30);
            response.sendRedirect("/webapp/Home");
        }
    }
}
