package com.tracking.tsaapp.dao;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.tracking.tsaapp.converter.ActivityConverter;
import com.tracking.tsaapp.model.Activity;
import java.util.ArrayList;
import java.util.List;
import org.bson.types.ObjectId;

public class ActivityDao {
    private DBCollection col;
    public ActivityDao(MongoClient mongo) {
        this.col = mongo.getDB("tracking").getCollection("activities");
    }
    public Activity createActivity(Activity a) {
        DBObject doc = ActivityConverter.toDBObject(a);
        this.col.insert(doc);
        ObjectId id = (ObjectId) doc.get("_id");
        a.setId(id.toString());
        return a;
    }

    public void updateActivity(Activity a) {
        DBObject query = BasicDBObjectBuilder.start()
                .append("_id", new ObjectId(a.getId())).get();
        this.col.update(query, ActivityConverter.toDBObject(a));
    }

    public List<Activity> readAllActivities(String iduser) {

        List<Activity> data = new ArrayList<Activity>();
        DBObject query = BasicDBObjectBuilder.start().add("iduser", iduser).get();
        DBCursor cursor = col.find(query);
        while (cursor.hasNext()) {
            DBObject doc = cursor.next();
            Activity a = ActivityConverter.toActivity(doc);
            data.add(a);
        }
        return data;
    }

    public void deleteActivity(Activity a) {
        DBObject query = BasicDBObjectBuilder.start()
                .append("_id", new ObjectId(a.getId())).get();
        this.col.remove(query);
    }

    public Activity readActivity(Activity a) {
        DBObject query = BasicDBObjectBuilder.start()
                .append("_id", new ObjectId(a.getId())).get();
        DBObject data = this.col.findOne(query);
        return ActivityConverter.toActivity(data);
    }
}
