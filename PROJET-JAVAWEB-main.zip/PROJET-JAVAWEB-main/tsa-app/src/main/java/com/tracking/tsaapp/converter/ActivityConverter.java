package com.tracking.tsaapp.converter;

import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBObject;
import com.tracking.tsaapp.model.Activity;
import com.tracking.tsaapp.model.User;
import org.bson.types.ObjectId;

import java.util.Date;

public class ActivityConverter {
    // convert Person Object to MongoDB DBObject
    // take special note of converting id String to ObjectId
    public static DBObject toDBObject(Activity a) {

        BasicDBObjectBuilder builder = BasicDBObjectBuilder.start()
                .append("type", a.getType()).append("iduser", a.getIduser())
                .append("datedebut",a.getDatedebut())
                .append("datefin",a.getDatefin());
        if (a.getId() != null)
            builder = builder.append("_id", new ObjectId(a.getId()));
        return builder.get();
    }

    // convert DBObject Object to Person
    // take special note of converting ObjectId to String
    public static Activity toActivity(DBObject doc) {
        Activity a=new Activity();

        a.setType((String) doc.get("type"));
        a.setIduser((String) doc.get("iduser"));
        a.setDatedebut((Date) doc.get("datedebut"));
        a.setDatefin((Date) doc.get("datefin"));
        ObjectId id = (ObjectId) doc.get("_id");
        a.setId(id.toString());
        return a;

    }
}
