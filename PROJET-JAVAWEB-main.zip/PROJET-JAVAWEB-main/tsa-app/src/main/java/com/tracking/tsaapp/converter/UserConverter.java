package com.tracking.tsaapp.converter;

import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBObject;
import com.tracking.tsaapp.model.User;
import org.bson.types.ObjectId;

public class UserConverter {
    // convert Person Object to MongoDB DBObject
    // take special note of converting id String to ObjectId
    public static DBObject toDBObject(User u) {

        BasicDBObjectBuilder builder = BasicDBObjectBuilder.start()
                .append("login", u.getUsername()).append("email", u.getEmail())
                .append("password",u.getPassword());
        if (u.getId() != null)
            builder = builder.append("_id", new ObjectId(u.getId()));
        return builder.get();
    }

    // convert DBObject Object to Person
    // take special note of converting ObjectId to String
    public static User toUser(DBObject doc) {
        User u = new User();
        u.setUsername((String) doc.get("login"));
        u.setEmail((String) doc.get("email"));
        u.setPassword((String) doc.get("password"));
        ObjectId id = (ObjectId) doc.get("_id");
        u.setId(id.toString());
        return u;

    }
}
