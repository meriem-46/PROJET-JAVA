package com.tracking.tsaapp.model;

import com.mongodb.DBObject;

import java.util.*;


public class Activity {
    private String id;
    private String type;
    private String iduser;

    private Date   datedebut;
    private Date   datefin;
    private List<Position> positions= new ArrayList<>();

    public Activity(String type, String iduser, Date datedebut,Date datefin,List<Position> positions) {
        this.type = type;
        this.iduser = iduser;
        this.datedebut = datedebut;
        this.datefin = datefin;
        this.positions=positions;
    }

    public Activity() {

    }



    public List<Position> getPositions() {return positions;}
    public void setPositions(List<Position> positions) {this.positions = positions;}
    public String getId() {return id;}
    public void setId(String id) {this.id = id;}
    public String getType() {return type;}
    public void setType(String type) {this.type = type;}
    public String getIduser() {return iduser;}
    public void setIduser(String iduser) {this.iduser = iduser;}

    public Date getDatedebut() {return datedebut;}

    public void setDatedebut(Date datedebut) {this.datedebut = datedebut;}

    public Date getDatefin() {return datefin;}

    public void setDatefin(Date datefin) {this.datefin = datefin;}
}
