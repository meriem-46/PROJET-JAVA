package com.tracking.tsaapp.dao;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.tracking.tsaapp.converter.UserConverter;
import com.tracking.tsaapp.model.User;
import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;

public class UserDao {
    private DBCollection col;

    public UserDao(MongoClient mongo) {
        this.col = mongo.getDB("tracking").getCollection("users");
    }

    public User createUser(User u) {
        DBObject doc = UserConverter.toDBObject(u);
        this.col.insert(doc);
        ObjectId id = (ObjectId) doc.get("_id");
        u.setId(id.toString());
        return u;
    }

    public void updateUser(User u) {
        DBObject query = BasicDBObjectBuilder.start()
                .append("_id", new ObjectId(u.getId())).get();
        this.col.update(query, UserConverter.toDBObject(u));
    }

    public List<User> readAllUsers() {
        List<User> data = new ArrayList<User>();
        DBCursor cursor = col.find();
        while (cursor.hasNext()) {
            DBObject doc = cursor.next();
            User u = UserConverter.toUser(doc);
            data.add(u);
        }
        return data;
    }

    public void deleteUser(User u) {
        DBObject query = BasicDBObjectBuilder.start()
                .append("_id", new ObjectId(u.getId())).get();
        this.col.remove(query);
    }

    public User readUser(User u) {
        DBObject query = BasicDBObjectBuilder.start()
                .append("_id", new ObjectId(u.getId())).get();
        DBObject data = this.col.findOne(query);
        return UserConverter.toUser(data);
    }
}
