package com.tracking.tsaapp.converter;

import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBObject;
import com.tracking.tsaapp.model.Position;
import org.bson.types.ObjectId;



public class PositionConverter {
    // convert Person Object to MongoDB DBObject
    // take special note of converting id String to ObjectId
    public static DBObject toDBObject(Position u) {

        BasicDBObjectBuilder builder = BasicDBObjectBuilder.start()
                .append("latitude", u.getLatitude()).append("longitude", u.getLongitude());
        if (u.getId() != null)
            builder = builder.append("_id", new ObjectId(u.getId()));
        return builder.get();
    }

    // convert DBObject Object to Person
    // take special note of converting ObjectId to String
    public static Position toPosition(DBObject doc) {
        Position p = new Position();
        p.setLatitude((double) doc.get("latitude"));
        p.setLongitude((double) doc.get("longitude"));
        ObjectId id = (ObjectId) doc.get("_id");
        p.setId(id.toString());
        return p;

    }
}
