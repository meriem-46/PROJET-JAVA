package com.tracking.tsaapp.controller;


import com.mongodb.MongoClient;
import com.tracking.tsaapp.dao.UserDao;
import com.tracking.tsaapp.model.User;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Register", value = "/Register")
public class Register extends HttpServlet {
    private static final long serialVersionUID = 1L;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.getServletContext()
                .getRequestDispatcher("/WEB-INF/views/register.jsp")
                .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String login = request.getParameter("login");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirm_password = request.getParameter("confirm_password");

        if ((login == null || login.equals(""))
                || (email == null || email.equals(""))
                || (password == null || password.equals(""))
                || (confirm_password == null || confirm_password.equals(""))) {
            request.setAttribute("error", "Mandatory Parameters Missing");
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/WEB-INF/views/register.jsp");
            rd.forward(request, response);
        } else if(password.equals(confirm_password)) {
            User u = new User();
            u.setId("");
            u.setEmail(email);
            u.setUsername(login);
            u.setPassword(password);

            MongoClient mongo = (MongoClient) request.getServletContext()
                    .getAttribute("MONGO_CLIENT");
            UserDao userDAO = new UserDao(mongo);
            userDAO.createUser(u);
            System.out.println("Person Added Successfully with id="+u.getId());
            request.setAttribute("success", "User Added Successfully");

            HttpSession session = request.getSession();
            session.setAttribute("login", u.getUsername());
            session.setAttribute("id", u.getId());
            session.setMaxInactiveInterval(60*30);
            RequestDispatcher rd = getServletContext().getRequestDispatcher(
                    "/WEB-INF/views/home.jsp");
            rd.forward(request, response);
        }
    }
}
