package com.tracking.tsaapp.model;

import java.util.Date;

public class Position {
    private String id;;
    private double longitude;
    private double latitude;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getLongitude() {return longitude;}
    public void setLongitude(double logitude) {this.longitude = logitude;}
    public double getLatitude() {return latitude;}
    public void setLatitude(double latitude) {this.latitude = latitude;}
}
